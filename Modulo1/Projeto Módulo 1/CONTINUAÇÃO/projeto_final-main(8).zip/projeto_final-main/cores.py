class Cores:
    def __init__(self):
        self.magentaON = '\033[1;35;40m'
        self.magentaOFF = '\033[m'
        self.yellowON = '\033[0;33;40m'
        self.yellowOFF = '\033[m'
        self.greenON = '\033[1;32;40m'
        self.greenOFF = '\033[m'
        self.cyanON = '\033[1;36;40m'
        self.cyanOFF = '\033[m'
        self.redON = '\033[1;31;40m'
        self.redOFF = '\033[m'
