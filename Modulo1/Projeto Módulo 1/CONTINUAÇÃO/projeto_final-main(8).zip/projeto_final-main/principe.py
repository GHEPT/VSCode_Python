class Principe:
    def __init__(self, amor=0):
        self.amor = 0


    def amar(self, pontos_de_amor):
        self.amor += pontos_de_amor


